const config = {
    // Server URL 
    server: 'http://localhost:5000/api',
    nodeEnv: 'production'
}

export default config;